create TYPE          "country622_T"              AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","countryId" NUMBER(38),"countryName" VARCHAR2(4000 CHAR),"region" "region623_T")FINAL INSTANTIABLE
/

