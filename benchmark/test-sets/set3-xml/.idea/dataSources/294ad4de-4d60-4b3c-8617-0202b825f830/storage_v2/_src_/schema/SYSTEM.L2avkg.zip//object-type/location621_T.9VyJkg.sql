create TYPE          "location621_T"              AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","locationId" NUMBER(38),"address" VARCHAR2(4000 CHAR),"postalCode" VARCHAR2(4000 CHAR),"city" VARCHAR2(4000 CHAR),"country" "country622_T")FINAL INSTANTIABLE
/

