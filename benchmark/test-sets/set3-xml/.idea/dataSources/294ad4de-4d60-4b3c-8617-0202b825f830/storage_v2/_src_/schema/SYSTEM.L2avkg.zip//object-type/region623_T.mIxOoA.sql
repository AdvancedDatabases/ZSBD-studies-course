create TYPE          "region623_T"              AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","regionId" NUMBER(38),"regionName" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

