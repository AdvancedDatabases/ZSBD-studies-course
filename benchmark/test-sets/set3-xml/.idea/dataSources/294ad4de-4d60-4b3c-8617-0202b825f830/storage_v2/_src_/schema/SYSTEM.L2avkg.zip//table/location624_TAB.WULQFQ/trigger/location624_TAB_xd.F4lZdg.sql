create trigger "location624_TAB$xd"
    after update or delete
    on "location624_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('SYSTEM','location624_TAB', :old.sys_nc_oid$, 'A41B74DE62F50794E053020018ACB9D5' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('SYSTEM','location624_TAB', :old.sys_nc_oid$, 'A41B74DE62F50794E053020018ACB9D5', user ); END IF; END;
/

