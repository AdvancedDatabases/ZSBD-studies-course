create trigger STOP1
    before insert
    on STOP1
BEGIN
    DBMS_OUTPUT.PUT_LINE('CALLING STOP 1');
    INSERT INTO stop2(message) values ('sth');
END;
/

