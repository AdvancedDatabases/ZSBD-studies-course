create trigger STOP2
    before insert
    on STOP2
BEGIN
    DBMS_OUTPUT.PUT_LINE('CALLING STOP 2');
    INSERT INTO stop3(message) values ('sth');
END;
/

