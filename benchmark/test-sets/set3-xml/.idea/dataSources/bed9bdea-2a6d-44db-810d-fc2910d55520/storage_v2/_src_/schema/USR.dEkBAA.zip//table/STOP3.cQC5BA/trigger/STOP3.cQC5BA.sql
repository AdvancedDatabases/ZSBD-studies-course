create trigger STOP3
    before insert
    on STOP3
BEGIN
    DBMS_OUTPUT.PUT_LINE('CALLING STOP 3');
    INSERT INTO stop1(message) values ('sth');
END;
/

